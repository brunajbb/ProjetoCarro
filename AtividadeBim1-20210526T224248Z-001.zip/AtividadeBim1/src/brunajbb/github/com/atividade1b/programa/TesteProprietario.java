package brunajbb.github.com.atividade1b.programa;

import brunajbb.github.com.atividade1b.classes.Endereco;
import brunajbb.github.com.atividade1b.classes.Proprietario;

public class TesteProprietario {

	public static void main(String[] args) {
		
		Endereco endereco = new Endereco("Rua exemplo", "Centro", "Curitiba", "PR", "00000-00");
		Proprietario prop = new Proprietario("Jo�o da Silva","001002003","123.456.789-00", endereco);
		
		System.out.println("NOME: " + prop.getNome());
		System.out.println("RG: " + prop.getRg());
		System.out.println("CPF: " + prop.getCpf());		
		// prop.getEndereco() -> retorna uma instacia de endere�o
		System.out.println("RUA: " + prop.getEndereco().getRua());
		System.out.println("CIDADE: " + prop.getEndereco().getCidade());
		
		// detro do objeto endere�o
		prop.getEndereco().setRua("Agora � uma nova rua!");		
		
		System.out.println("RUA: " + prop.getEndereco().getRua());

	}

}
