package brunajbb.github.com.atividade1b.programa;

import brunajbb.github.com.atividade1b.classes.Carro;
import brunajbb.github.com.atividade1b.classes.Endereco;
import brunajbb.github.com.atividade1b.classes.Proprietario;

public class TesteCarroProprietario {

	public static void main(String[] args){
		
		Endereco endereco = new Endereco("Rua exemplo", "Centro", "Curitiba", "PR", "00000-00");
		Proprietario prop = new Proprietario("Jo�o da Silva","001002003","123.456.789-00", endereco);

		Carro car = new Carro();
		// car -> instancia do objeto Carro
		car.setAno("2005");
		car.setCor("Preto");
		car.setChassi("AZX123456");
		car.setNumeroMarchas(6);
		car.setNumeroPortas(4);
		car.setModelo("Gol");
		car.setTemCambioAutomatico(false);
		car.setTemTetoSolar(false);

		//esta linha esta amarrando o proprietario ao atributo dentro do carro
		car.setProprietario(prop);
		
		// Carro -> Proprietario -> Endere�o
		System.out.println("Modelo: " + car.getModelo());
		System.out.println("Marca: " + car.getMarca());
		System.out.println("Ano: " + car.getAno());
		System.out.println("Nome do proprietario: " + car.getProprietario().getNome());
		System.out.println("CPF do proprietario: " + car.getProprietario().getCpf());
		System.out.println("RUA: " + car.getProprietario().getEndereco().getRua());
		
		car.acelerar(); //1
		car.acelerar(); //2
		car.aumentarMarcha(); //1
		car.acelerar(); //3
		
		car.aumentarMarcha(); //2
		car.acelerar(); //4
	
	}

}
