package brunajbb.github.com.atividade1b.programa;

import brunajbb.github.com.atividade1b.classes.ExemploInterface;

public class ImplementaInterface implements ExemploInterface{

	public static void main(String[] args) {
		

	}

	@Override
	public void escrever() {
		System.out.println("Qualquer coisa");		
	}

}
