package brunajbb.github.com.atividade1b.programa;

import java.util.ArrayList;

import brunajbb.github.com.atividade1b.classes.Endereco;
import brunajbb.github.com.atividade1b.classes.Proprietario;

public class TesteProprietarioEnderecos {

	public static void main(String[] args) {
		
		Endereco endereco = new Endereco("Rua exemplo", "Centro", "Curitiba", "PR", "00000-00");
		Endereco endereco2 = new Endereco("Rua exemplo2", "Centro", "Curitiba", "PR", "00000-00");
		ArrayList<Endereco> listaEnderecos = new ArrayList<>();
		listaEnderecos.add(endereco);
		listaEnderecos.add(endereco2);
		Proprietario prop = new Proprietario("Jo�o da Silva","001002003",
											 "123.456.789-00", listaEnderecos);
		
		System.out.println("Nome: " + prop.getNome());
		System.out.println("Quantos endere�os: " + prop.getEnderecos().size());
		for (int i = 0; i < prop.getEnderecos().size(); i++) {
			System.out.println("Rua: " + prop.getEnderecos().get(i).getRua());
		}

	}

}
