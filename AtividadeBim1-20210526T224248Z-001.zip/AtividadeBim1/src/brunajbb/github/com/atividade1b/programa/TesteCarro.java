package brunajbb.github.com.atividade1b.programa;

import brunajbb.github.com.atividade1b.classes.Carro;

public class TesteCarro {

	public static void main(String[] args) {
		Carro car = new Carro();
		car.setAno("2005");
		car.setCor("Preto");
		car.setChassi("AZX123456");
		car.setNumeroMarchas(6);
		car.setNumeroPortas(4);
		car.setModelo("Gol");
		car.setTemCambioAutomatico(false);
		car.setTemTetoSolar(false);

		car.acelerar(); //1
		car.acelerar(); //2
		car.aumentarMarcha(); //1
		car.acelerar(); //3
		
		car.aumentarMarcha(); //2
		car.acelerar(); //4
		
	}

}
