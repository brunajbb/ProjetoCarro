package brunajbb.github.com.atividade1b.programa;

import java.util.ArrayList;

import brunajbb.github.com.atividade1b.classes.Endereco;

public class TesteArrayList {
	
	public static void main(String[] args) {
		Endereco endereco1 = new Endereco("Rua exemplo1", "Centro", "Curitiba", "PR", "00000-00");
		Endereco endereco2 = new Endereco("Rua exemplo2", "Centro", "Curitiba", "PR", "00000-00");
		
		ArrayList<Endereco> arrayList = new ArrayList<>();
		arrayList.add(endereco1);
		arrayList.add(endereco2);
				
		for (int i = 0; i < arrayList.size() ; i++) {
			System.out.println(arrayList.get(i).toString());	
		}
//		arrayListInteiros.forEach(item -> System.out.println(item));
		
		
	}
}
