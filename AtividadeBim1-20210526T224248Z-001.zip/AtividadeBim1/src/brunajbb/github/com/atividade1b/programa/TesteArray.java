package brunajbb.github.com.atividade1b.programa;

import brunajbb.github.com.atividade1b.classes.Endereco;

public class TesteArray {

	public static void main(String[] args) {
		/*
		 * 
		int numero = 1;
		
		int numeros[] = {0,numero,2,3,4};
		
		int numeros2[] = new int[5];
		
		numeros2[0] = 0;
		numeros2[1] = 1;
		numeros2[2] = 2;
		numeros2[3] = 3;
		numeros2[4] = 4;
		
		System.out.println(numeros[0]);
		System.out.println(numeros[3]);
		
		System.out.println(numeros2[0]);
		System.out.println(numeros2[3]);
		
		String vetorPalavras[] = {"Palavra 1", "Palavra 2"};
		*   
		*/
		// estrura que pode receber at� 2
		Endereco vetorEnderecos[] = new Endereco[2];
		Endereco endereco1 = new Endereco("Rua exemplo1", "Centro", "Curitiba", "PR", "00000-00");
		Endereco endereco2 = new Endereco("Rua exemplo2", "Centro", "Curitiba", "PR", "00000-00");
		vetorEnderecos[0] = endereco1;
		vetorEnderecos[1] = endereco2;
		
		for (int i = 0; i < vetorEnderecos.length; i++) {
			System.out.println(vetorEnderecos[i].getRua());
		}
	}
}
