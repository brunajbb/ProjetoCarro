package brunajbb.github.com.atividade1b.classes;

public interface ExemploInterface {

	void escrever();
}
